package dao;

public class studprofDao {

}
