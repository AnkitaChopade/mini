package controller;

public class studprof {

}
